/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
class Calender {

    static Calender getInstance() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

}
